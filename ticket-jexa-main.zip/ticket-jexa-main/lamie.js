const { 
    Client, 
    GatewayIntentBits, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    StringSelectMenuOptionBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    PermissionsBitField, 
    ChannelType,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
    RoleSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    ChannelType: { GuildText, GuildCategory }
} = require('discord.js');
const { joinVoiceChannel } = require('@discordjs/voice');
const ayarlar = require('./ayarlar.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates
    ]
});

const prefix = ayarlar.prefix;
const hedefSunucuID = '1512219486575525898';
const hedefSesKanalID = '1512231230773395680';

const p = '> ';

const activeTickets = new Map();
let ticketCounter = {};

Object.keys(ayarlar.kategoriler).forEach(k => {
    ticketCounter[k] = ayarlar.db[`counter_${k}`] || 0;
});

client.once('ready', async () => {
    console.log(`${client.user.tag} aktif!`);
    console.log('Destek Sistemi Hazır.');
    console.log('made by 25f4 and katliamcxn');

    const durumlar = [
        "Only 'A'",
        "'A' > everything",
        "One heart, one 'A'"
    ];
    let durum_index = 0;

    const durum_guncelle = async () => {
        try {
            await client.user.setActivity(durumlar[durum_index]);
            durum_index = (durum_index + 1) % durumlar.length;
        } catch (err) {
            console.log('Durum güncellenirken hata:', err.message);
        }
    };

    durum_guncelle();

    setInterval(durum_guncelle, 10000);

    const hedefSunucu = client.guilds.cache.get(hedefSunucuID);
    if (!hedefSunucu) {
        console.log('Hedef sunucu bulunamadı!');
        return;
    }

    const hedefKanal = hedefSunucu.channels.cache.get(hedefSesKanalID);
    if (!hedefKanal) {
        console.log('Hedef ses kanalı bulunamadı!');
        return;
    }

    try {
        joinVoiceChannel({
            channelId: hedefSesKanalID,
            guildId: hedefSunucuID,
            adapterCreator: hedefSunucu.voiceAdapterCreator,
            selfDeaf: true,
            selfMute: false
        });
        
        console.log(`Ses kanalına bağlanıldı: ${hedefKanal.name}`);
    } catch (err) {
        console.log('Ses kanalına bağlanılamadı:', err.message);
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'destek-ayarlar') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply(`Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısınız!`);
        }

        const eksikAyarlar = [];
        if (!ayarlar.yetkiliRolID) eksikAyarlar.push('<:yetkili:1512411372066046054> Yetkili Rolü');
        if (!ayarlar.ticketKategoriID) eksikAyarlar.push('<:category:1512411662479659040> Ticket Kategorisi');
        if (!ayarlar.panelKanalID) eksikAyarlar.push('<:channel:1512412945202806938> Panel Kanalı');

        if (eksikAyarlar.length > 0) {
            return message.reply(
                `Aşağıdaki ayarlar tamamlanmamış:\n` +
                eksikAyarlar.map(a => `${a}`).join('\n') +
                `\n\n\`${prefix}destek-ayarlar\` ile ayarlayın.`
            );
        }

        const panelKanal = message.guild.channels.cache.get(ayarlar.panelKanalID);
        if (!panelKanal) {
            return message.reply(`Panel kanalı bulunamadı! Ayarları kontrol edin.`);
        }

        const baslikText = new TextDisplayBuilder().setContent(`<:ayarlar:1512403991072608390> **Destek Sistemi Ayarları**`);
        
        const bilgiText = new TextDisplayBuilder().setContent(
            `Aşağıdaki menülerden tüm ayarları yapılandırabilirsiniz.\n` +
            `Ayarlar otomatik olarak kaydedilir ve anında aktif olur.\n` +
            `Tüm ayarlar tamamlandıktan sonra \`${prefix}destek-panel\` komutunu kullanın.`
        );

        const sep1 = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);

        const yetkiliText = new TextDisplayBuilder().setContent(
            `### <:yetkili:1512411372066046054> Yetkili Rolü\n` +
            `Mevcut: ${ayarlar.yetkiliRolID ? `<@&${ayarlar.yetkiliRolID}>` : '<:hayir:1512405579874832515> Ayarlanmamış'}`
        );

        const yetkiliSelect = new RoleSelectMenuBuilder()
            .setCustomId('ayar_yetkili_rol')
            .setPlaceholder('Yetkili rolü seç...')
            .setMinValues(1)
            .setMaxValues(1);

        const yetkiliRow = new ActionRowBuilder().addComponents(yetkiliSelect);

        const sep2 = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);

        const kategoriText = new TextDisplayBuilder().setContent(
            `### <:category:1512411662479659040> Ticket Kategorisi\n` +
            `Mevcut: ${ayarlar.ticketKategoriID ? `<#${ayarlar.ticketKategoriID}>` : '<:hayir:1512405579874832515> Ayarlanmamış'}`
        );

        const kategoriSelect = new ChannelSelectMenuBuilder()
            .setCustomId('ayar_ticket_kategori')
            .setPlaceholder('Ticket kategorisi seç...')
            .setChannelTypes(GuildCategory)
            .setMinValues(1)
            .setMaxValues(1);

        const kategoriRow = new ActionRowBuilder().addComponents(kategoriSelect);

        const sep3 = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);

        const logText = new TextDisplayBuilder().setContent(
            `### <:channel:1512412945202806938> Log Kanalı\n` +
            `Mevcut: ${ayarlar.logKanalID ? `<#${ayarlar.logKanalID}>` : '<:hayir:1512405579874832515> Ayarlanmamış'}`
        );

        const logSelect = new ChannelSelectMenuBuilder()
            .setCustomId('ayar_log_kanal')
            .setPlaceholder('Log kanalı seç...')
            .setChannelTypes(GuildText)
            .setMinValues(1)
            .setMaxValues(1);

        const logRow = new ActionRowBuilder().addComponents(logSelect);

        const sep4 = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);

        const panelText = new TextDisplayBuilder().setContent(
            `### <:channel:1512412945202806938> Panel Kanalı\n` +
            `Mevcut: ${ayarlar.panelKanalID ? `<#${ayarlar.panelKanalID}>` : '<:hayir:1512405579874832515> Ayarlanmamış'}`
        );

        const panelSelect = new ChannelSelectMenuBuilder()
            .setCustomId('ayar_panel_kanal')
            .setPlaceholder('Panel kanalı seç...')
            .setChannelTypes(GuildText)
            .setMinValues(1)
            .setMaxValues(1);

        const panelRow = new ActionRowBuilder().addComponents(panelSelect);

        const sep5 = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);

        const durumText = new TextDisplayBuilder().setContent(
            `### <:ayarlar:1512403991072608390> Ayar Durumu\n` +
            `${ayarlar.yetkiliRolID ? '<:evet:1512405631880003635>' : '<:hayir:1512405579874832515>'} Yetkili Rolü\n` +
            `${ayarlar.ticketKategoriID ? '<:evet:1512405631880003635>' : '<:hayir:1512405579874832515>'} Ticket Kategorisi\n` +
            `${ayarlar.logKanalID ? '<:evet:1512405631880003635>' : '<:hayir:1512405579874832515>'} Log Kanalı\n` +
            `${ayarlar.panelKanalID ? '<:evet:1512405631880003635>' : '<:hayir:1512405579874832515>'} Panel Kanalı`
        );

        const container = new ContainerBuilder()
            .setAccentColor(0x8b5cf6)
            .addTextDisplayComponents(baslikText)
            .addTextDisplayComponents(bilgiText)
            .addSeparatorComponents(sep1)
            .addTextDisplayComponents(yetkiliText)
            .addActionRowComponents(yetkiliRow)
            .addSeparatorComponents(sep2)
            .addTextDisplayComponents(kategoriText)
            .addActionRowComponents(kategoriRow)
            .addSeparatorComponents(sep3)
            .addTextDisplayComponents(logText)
            .addActionRowComponents(logRow)
            .addSeparatorComponents(sep4)
            .addTextDisplayComponents(panelText)
            .addActionRowComponents(panelRow)
            .addSeparatorComponents(sep5)
            .addTextDisplayComponents(durumText);

        await message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }

    if (command === 'destek-panel') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply(`Bu komutu kullanmak için **Yönetici** yetkisine sahip olmalısınız!`);
        }

        const eksikAyarlar = [];
        if (!ayarlar.yetkiliRolID) eksikAyarlar.push('<:yetkili:1512411372066046054> Yetkili Rolü');
        if (!ayarlar.ticketKategoriID) eksikAyarlar.push('<:category:1512411662479659040> Ticket Kategorisi');
        if (!ayarlar.panelKanalID) eksikAyarlar.push('<:channel:1512412945202806938> Panel Kanalı');

        if (eksikAyarlar.length > 0) {
            return message.reply(
                `Aşağıdaki ayarlar tamamlanmamış:\n` +
                eksikAyarlar.map(a => `${a}`).join('\n') +
                `\n\n\`${prefix}destek-ayarlar\` ile ayarlayın.`
            );
        }

        const panelKanal = message.guild.channels.cache.get(ayarlar.panelKanalID);
        if (!panelKanal) {
            return message.reply(`Panel kanalı bulunamadı! Ayarları kontrol edin.`);
        }

        const baslikText2 = new TextDisplayBuilder().setContent(`<a:ticket:1512405387863658516> **Ticket Paneli**`);
        
        const bilgiText2 = new TextDisplayBuilder().setContent(
            `*Herhangi bir sorun, soru veya talebiniz için aşağıdaki seçim menüsünü kullanabilirsiniz. İhtiyacınıza en uygun kategoriyi seçerek hızlı ve düzenli bir şekilde destek talebi oluşturabilirsiniz.*`
        );

        const sep1_panel = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);
        
        const kuralText2 = new TextDisplayBuilder().setContent(`<:rules:1512228700211511339> **Ticket Rules**`);
        
        const kurallarList2 = new TextDisplayBuilder().setContent(
            `*Sorununuzu detaylı bir şekilde açıklayınız. Yaşadığınız problemi, hata mesajlarını, ilgili ekran görüntülerini ve gerekli tüm bilgileri eksiksiz paylaşmanız, ekibimizin size daha hızlı ve doğru şekilde yardımcı olmasını sağlar.*`
        );

        const sep2_panel = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);

        const footerText2 = new TextDisplayBuilder().setContent(`-# developed  by <@1333819555264593992>`);

        const selectMenu2 = new StringSelectMenuBuilder()
            .setCustomId('destek_kategori_secim')
            .setPlaceholder('Destek açmak için kategori seçin...')
            .addOptions(
                new StringSelectMenuOptionBuilder()
                    .setLabel(ayarlar.kategoriler.genel.isim)
                    .setDescription(ayarlar.kategoriler.genel.aciklama)
                    .setValue('genel')
                    .setEmoji({ id: '1512228671929323681' }),
                new StringSelectMenuOptionBuilder()
                    .setLabel(ayarlar.kategoriler.teknik.isim)
                    .setDescription(ayarlar.kategoriler.teknik.aciklama)
                    .setValue('teknik')
                    .setEmoji({ id: '1512403991072608390' }),
                new StringSelectMenuOptionBuilder()
                    .setLabel(ayarlar.kategoriler.satis.isim)
                    .setDescription(ayarlar.kategoriler.satis.aciklama)
                    .setValue('satis')
                    .setEmoji({ id: '1512396876035653672' }),
                new StringSelectMenuOptionBuilder()
                    .setLabel(ayarlar.kategoriler.sikayet.isim)
                    .setDescription(ayarlar.kategoriler.sikayet.aciklama)
                    .setValue('sikayet')
                    .setEmoji({ id: '1512404556737413311' })
            );

        const actionRow2 = new ActionRowBuilder().addComponents(selectMenu2);

        const container2 = new ContainerBuilder()
            .setAccentColor(0x8b5cf6)
            .addTextDisplayComponents(baslikText2)
            .addTextDisplayComponents(bilgiText2)
            .addSeparatorComponents(sep1_panel)
            .addTextDisplayComponents(kuralText2)
            .addTextDisplayComponents(kurallarList2)
            .addSeparatorComponents(sep2_panel)
            .addTextDisplayComponents(footerText2)
            .addActionRowComponents(actionRow2);

        await panelKanal.send({
            components: [container2],
            flags: MessageFlags.IsComponentsV2
        });
        
        message.reply({
            content: `<:evet:1512405631880003635> Destek paneli <#${panelKanal.id}> kanalına gönderildi!`,
            ephemeral: true
        });
    }

    if (command === 'help' || command === 'yardım') {
        const helpMenu = new StringSelectMenuBuilder()
            .setCustomId('help_menu_select')
            .setPlaceholder('Bilgi almak istediğiniz komutu seçin...')
            .addOptions(
                new StringSelectMenuOptionBuilder()
                    .setLabel('.destek-ayarlar')
                    .setDescription('Ticket sistemini yapılandır')
                    .setValue('ayarlar')
                    .setEmoji({ id: '1512403991072608390' }),
                new StringSelectMenuOptionBuilder()
                    .setLabel('.destek-panel')
                    .setDescription('Destek panelini kanalına gönder')
                    .setValue('panel')
                    .setEmoji({ id: '1512405387863658516' }),
                new StringSelectMenuOptionBuilder()
                    .setLabel('Hakkımda')
                    .setDescription('Bot hakkında bilgi')
                    .setValue('hakkimda')
                    .setEmoji({ id: '1512228671929323681' })
            );

        const helpRow = new ActionRowBuilder().addComponents(helpMenu);

        await message.reply({
            components: [helpRow],
            ephemeral: true
        });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isStringSelectMenu() && !interaction.isButton() && !interaction.isRoleSelectMenu() && !interaction.isChannelSelectMenu()) return;

    if (interaction.isRoleSelectMenu()) {
        if (interaction.customId === 'ayar_yetkili_rol') {
            ayarlar.yetkiliRolID = interaction.values[0];
            await interaction.reply({
                content: `${p}<:evet:1512405631880003635> Yetkili rolü <@&${interaction.values[0]}> olarak ayarlandı!`,
                ephemeral: true
            });
        }
    }

    if (interaction.isChannelSelectMenu()) {
        if (interaction.customId === 'ayar_ticket_kategori') {
            ayarlar.ticketKategoriID = interaction.values[0];
            await interaction.reply({
                content: `${p}<:evet:1512405631880003635> Ticket kategorisi <#${interaction.values[0]}> olarak ayarlandı!`,
                ephemeral: true
            });
        }
        
        if (interaction.customId === 'ayar_log_kanal') {
            ayarlar.logKanalID = interaction.values[0];
            await interaction.reply({
                content: `${p}<:evet:1512405631880003635> Log kanalı <#${interaction.values[0]}> olarak ayarlandı!`,
                ephemeral: true
            });
        }
        
        if (interaction.customId === 'ayar_panel_kanal') {
            ayarlar.panelKanalID = interaction.values[0];
            await interaction.reply({
                content: `${p}<:evet:1512405631880003635> Panel kanalı <#${interaction.values[0]}> olarak ayarlandı!`,
                ephemeral: true
            });
        }
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'help_menu_select') {
        const secim = interaction.values[0];
        let helpText = '';

        if (secim === 'ayarlar') {
            helpText = 
                `### <:ayarlar:1512403991072608390> .destek-ayarlar\n\n` +
                `Komut Kullanımı: denetim\n` +
                `Komut Açıklaması: Ticket sistemini yapılandır\n` +
                `Örnek:\n` +
                `→ \`.destek-ayarlar\`\n\n` +
                `Bu komut ile:\n` +
                `<:dot:1512227879964901447> Yetkili rolü ayarlayabilirsiniz\n` +
                `<:dot:1512227879964901447> Ticket kategorisini seçebilirsiniz\n` +
                `<:dot:1512227879964901447> Log kanalını belirleyebilirsiniz\n` +
                `<:dot:1512227879964901447> Panel kanalını ayarlayabilirsiniz`;
        } else if (secim === 'panel') {
            helpText = 
                `### <a:ticket:1512405387863658516> .destek-panel\n\n` +
                `Komut Kullanımı: denetim\n` +
                `Komut Açıklaması: Destek panelini kanalına gönder\n` +
                `Örnek:\n` +
                `→ \`.destek-panel\`\n\n` +
                `Bu komut ile:\n` +
                `<:dot:1512227879964901447> Destek paneli panel kanalına gönderilir\n` +
                `<:dot:1512227879964901447> Kullanıcılar ticket açabilirler\n` +
                `<:dot:1512227879964901447> Kategori seçim menüsü görülür\n` +
                `<:dot:1512227879964901447> Tüm ayarlar yapılandırılmışsa çalışır`;
        } else if (secim === 'hakkimda') {
            helpText = 
                `<:dev:1512394537769766963> Bu Botlar <@1333819555264593992> *Tarafından Bu Sunucuya Özel Olarak Yapılmıştır.*\n\n` +
                `<a:aButterflys:1512395003043905617> *Sende Bot Yaptırmak İçin <@1333819555264593992> ile iletişime geçebilirsiniz.*`;
        }

        await interaction.reply({
            content: helpText,
            ephemeral: true
        });
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'destek_kategori_secim') {
        if (!ayarlar.yetkiliRolID || !ayarlar.ticketKategoriID) {
            return interaction.reply({
                content: `${p}<:hayir:1512405579874832515> Sistem ayarları tamamlanmamış! Yöneticiye bildirin.`,
                ephemeral: true
            });
        }

        const secilen = interaction.values[0];
        const kategori = ayarlar.kategoriler[secilen];
        const guild = interaction.guild;
        const member = interaction.member;

        const userActiveTickets = Array.from(activeTickets.values()).filter(t => t.userID === member.id);
        if (userActiveTickets.length >= 3) {
            return interaction.reply({
                content: `${p}<:hayir:1512405579874832515> Aynı anda en fazla 3 ticket açabilirsiniz! Mevcut ticketlarınızı kapatın.`,
                ephemeral: true
            });
        }
        ticketCounter[secilen] = (ticketCounter[secilen] || 0) + 1;
        const kategoriSlug = secilen === 'genel' ? 'genel-destek' : 
                            secilen === 'teknik' ? 'teknik-destek' : 
                            secilen === 'satış' ? 'satış-destek' : 'şikayet-destek';
        
        const ticketName = `🎫・${kategoriSlug}-${ticketCounter[secilen]}`;
        
        ayarlar.db[`counter_${secilen}`] = ticketCounter[secilen];
        ayarlar.save(ayarlar.db);

        const ticketKategori = guild.channels.cache.get(ayarlar.ticketKategoriID);
        
        const ticketChannel = await guild.channels.create({
            name: ticketName,
            type: ChannelType.GuildText,
            parent: ticketKategori ? ticketKategori.id : null,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: member.id,
                    allow: [
                        PermissionsBitField.Flags.ViewChannel,
                        PermissionsBitField.Flags.SendMessages,
                        PermissionsBitField.Flags.ReadMessageHistory,
                        PermissionsBitField.Flags.AttachFiles,
                        PermissionsBitField.Flags.EmbedLinks
                    ]
                },
                {
                    id: ayarlar.yetkiliRolID,
                    allow: [
                        PermissionsBitField.Flags.ViewChannel,
                        PermissionsBitField.Flags.SendMessages,
                        PermissionsBitField.Flags.ReadMessageHistory,
                        PermissionsBitField.Flags.ManageMessages,
                        PermissionsBitField.Flags.ManageChannels
                    ]
                }
            ]
        });

        activeTickets.set(ticketChannel.id, {
            userID: member.id,
            kategori: kategori.isim,
            channelID: ticketChannel.id,
            ticketNum: ticketCounter,
            acilisZamani: Date.now()
        });

        ayarlar.db.toplamTicket = (ayarlar.db.toplamTicket || 0) + 1;
        ayarlar.db.bugunTicket = (ayarlar.db.bugunTicket || 0) + 1;
        ayarlar.save(ayarlar.db);

        const ticketBaslik = new TextDisplayBuilder().setContent(`<:info:1512420240003305673> **Ticket #${ticketCounter[secilen]}**`);
        
        const ticketBilgi = new TextDisplayBuilder().setContent(
            `${p}<:info:1512420240003305673> **Kategori:** ${kategori.isim}\n` +
            `${p}<:yaz:1512420819689541713> **Oluşturan:** <@${member.id}>\n` +
            `${p}<:tarih:1512420854821028012> **Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`
        );

        const sep1 = new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small);

        const kurallarText = new TextDisplayBuilder().setContent(
            `${p}Lütfen sorunuzu detaylı bir şekilde açıklayın.\n` +
            `${p}Destek ekibimiz en kısa sürede yardımcı olacak.`
        );

        const kapatButton = new ButtonBuilder()
            .setCustomId('ticket_kapat')
            .setLabel('Kapat')
            .setEmoji({ id: '1512420299768070234' })
            .setStyle(ButtonStyle.Secondary);

        const yetkiliCagirButton = new ButtonBuilder()
            .setCustomId('ticket_yetkili_cagir')
            .setLabel('Yetkili Çağır')
            .setEmoji({ id: '1512420269124489299' })
            .setStyle(ButtonStyle.Primary);

        const bilgiButton = new ButtonBuilder()
            .setCustomId('ticket_bilgi')
            .setLabel('Bilgi')
            .setEmoji({ id: '1512420240003305673' })
            .setStyle(ButtonStyle.Secondary);

        const buttonRow = new ActionRowBuilder().addComponents(kapatButton, yetkiliCagirButton, bilgiButton);

        const ticketContainer = new ContainerBuilder()
            .setAccentColor(0x8b5cf6)
            .addTextDisplayComponents(ticketBaslik)
            .addTextDisplayComponents(ticketBilgi)
            .addSeparatorComponents(sep1)
            .addTextDisplayComponents(kurallarText)
            .addActionRowComponents(buttonRow);

        await ticketChannel.send({
            components: [ticketContainer],
            flags: MessageFlags.IsComponentsV2
        });

        await interaction.reply({
            content: `${p}<:evet:1512405631880003635> Destek talebiniz oluşturuldu! <#${ticketChannel.id}>`,
            ephemeral: true
        });

        const logKanal = guild.channels.cache.get(ayarlar.logKanalID);
        if (logKanal) {
            const logText = new TextDisplayBuilder().setContent(
                `<:info:1512420240003305673> **Ticket #${ticketCounter[secilen]}**\n` +
                `${p}<:yaz:1512420819689541713> **Kategori:** ${kategori.isim}\n` +
                `${p}<:bildirim:1512420269124489299> **Oluşturan:** <@${member.id}>\n` +
                `${p}<:tarih:1512420854821028012> **Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>`
            );
            
            const logContainer = new ContainerBuilder()
                .setAccentColor(0x43aa8b)
                .addTextDisplayComponents(logText);

            await logKanal.send({
                components: [logContainer],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }

    if (interaction.isButton() && interaction.customId === 'ticket_kapat') {
        const channel = interaction.channel;
        
        if (!channel.name.startsWith('🎫')) return;

        const member = interaction.member;
        const hasPermission = member.permissions.has(PermissionsBitField.Flags.Administrator) || 
                             member.roles.cache.has(ayarlar.yetkiliRolID) ||
                             channel.permissionOverwrites.cache.get(member.id)?.allow.has(PermissionsBitField.Flags.ViewChannel);

        if (!hasPermission) {
            return interaction.reply({
                content: `${p}<:hayir:1512405579874832515> Bu ticketı kapatma yetkiniz yok!`,
                ephemeral: true
            });
        }

        const ticketData = activeTickets.get(channel.id);
        const ticketNum = ticketData ? ticketData.ticketNum : '?';

        const kapatText = new TextDisplayBuilder().setContent(`<:info:1512420240003305673> Ticket Kapatılıyor`);
        
        const kapatBilgi = new TextDisplayBuilder().setContent(
            `${p}Kanal **5 saniye** içinde silinecek.\n` +
            `${p}Destek için tekrar tıkla açabilirsin.`
        );

        const kapatContainer = new ContainerBuilder()
            .setAccentColor(0xe63946)
            .addTextDisplayComponents(kapatText)
            .addTextDisplayComponents(kapatBilgi);

        await interaction.reply({
            components: [kapatContainer],
            flags: MessageFlags.IsComponentsV2
        });

        const logKanal = interaction.guild.channels.cache.get(ayarlar.logKanalID);

        const messages = await channel.messages.fetch({ limit: 100 }).catch(() => null);
        let transcript = '';
        if (messages) {
            transcript = messages.reverse().map(m => {
                const time = new Date(m.createdTimestamp).toLocaleString('tr-TR');
                return `[${time}] ${m.author.tag}: ${m.content || '[Embed/Component]'}`;
            }).join('\n');
        }

        if (logKanal) {
            const logText = new TextDisplayBuilder().setContent(
                `<:info:1512420240003305673> **Ticket Kapatıldı**\n` +
                `${p}<:bildirim:1512420269124489299> **Kapatıldı:** <@${member.id}>\n` +
                `${p}<:tarih:1512420854821028012> **Tarih:** <t:${Math.floor(Date.now() / 1000)}:F>\n` + +
                `${p}**Ticket Number #:** ${ticketNum}\n` +
                `${p}**Ticket'i Açan:** ${ticketData ? `<@${ticketData.userID}>` : 'Bilinmiyor'}\n` +
                `${p}**Kapatılma Tarihi:** <t:${Math.floor(Date.now() / 1000)}:F>`
            );
            
            const logContainer = new ContainerBuilder()
                .setAccentColor(0xe63946)
                .addTextDisplayComponents(logText);

            await logKanal.send({
                components: [logContainer],
                flags: MessageFlags.IsComponentsV2
            });

            if (transcript.length > 0 && transcript.length < 2000) {
                const transcriptText = new TextDisplayBuilder().setContent(
                    `**<a:ticket:1512405387863658516> ${channel.name} - Log:**\n\`\`\`\n${transcript.substring(0, 1900)}\n\`\`\``
                );
                
                const transcriptContainer = new ContainerBuilder()
                    .addTextDisplayComponents(transcriptText);

                await logKanal.send({
                    components: [transcriptContainer],
                    flags: MessageFlags.IsComponentsV2
                }).catch(() => {});
            }
        }

        activeTickets.delete(channel.id);

        setTimeout(() => channel.delete().catch(() => {}), 5000);
    }

    if (interaction.isButton() && interaction.customId === 'ticket_yetkili_cagir') {
        const channel = interaction.channel;
        if (!channel.name.startsWith('🎫')) return;

        const member = interaction.member;
        const yetkiliRole = interaction.guild.roles.cache.get(ayarlar.yetkiliRolID);
        if (!yetkiliRole) {
            return interaction.reply({
                content: `<:info:1512420240003305673> Yetkili rolü ayarlanmamış!`,
                ephemeral: true
            });
        }

        const yetkiliMembers = interaction.guild.members.cache.filter(member => member.roles.cache.has(ayarlar.yetkiliRolID));
        
        if (yetkiliMembers.size === 0) {
            return interaction.reply({
                content: `<:info:1512420240003305673> Şu anda yetkili yok!`,
                ephemeral: true
            });
        }

        let successCount = 0;
        const channel_mention = `<#${channel.id}>`;
        
        for (const staffMember of yetkiliMembers.values()) {
            try {
                await staffMember.send({
                    content: `<:bildirim:1512420269124489299> **Yetkili Çağırması!**\n\nKullanıcı: <@${interaction.user.id}>\nChannel: ${channel_mention}\n\nLütfen ilgilen.`
                });
                successCount++;
            } catch (err) {
                console.log(`${staffMember.user.tag}'a DM gönderilemedi`);
            }
        }

        await interaction.reply({
            content: `${p}<:evet:1512405631880003635> ${successCount} yetkili bildirildi!`,
            ephemeral: true
        });
    }

    if (interaction.isButton() && interaction.customId === 'ticket_bilgi') {
        const channel = interaction.channel;
        if (!channel.name.startsWith('🎫')) return;

        const ticketData = activeTickets.get(channel.id);
        if (!ticketData) {
            return interaction.reply({
                content: `${p}<:hayir:1512405579874832515> Bu ticket hakkında bilgi bulunamadı!`,
                ephemeral: true
            });
        }

        const acilisTarihi = new Date(ticketData.acilisZamani).toLocaleString('tr-TR');
        const kategoriEmoji = ticketData.kategori.includes('Genel') ? '<:info:1512228671929323681>' :
                             ticketData.kategori.includes('Teknik') ? '<:ayarlar:1512403991072608390>' :
                             ticketData.kategori.includes('Satış') ? '<:buyutec:1512396876035653672>' : '<:ampul:1512404556737413311>';

        const bilgiText = new TextDisplayBuilder().setContent(
            `## <a:ticket:1512405387863658516> Ticket #${ticketData.ticketNum}\n` +
            `${p}<:info:1512228671929323681> **Kategori:** ${kategoriEmoji} ${ticketData.kategori}\n` +
            `${p}<:tarih:1512420854821028012> **Açılış:** <t:${Math.floor(ticketData.acilisZamani / 1000)}:F>`
        );

        const bilgiContainer = new ContainerBuilder()
            .setAccentColor(0x8b5cf6)
            .addTextDisplayComponents(bilgiText);

        await interaction.reply({
            components: [bilgiContainer],
            flags: MessageFlags.IsComponentsV2,
            ephemeral: true
        });
    }

        await interaction.reply({
            content: `<:evet:1512405631880003635> **${successCount}** yetkili kişiye bildirim gönderildi!`,
            ephemeral: true
        });
    }
);

client.on('error', (err) => {
    console.error('Client Error:', err.message);
});

process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err.message);
});

client.login(ayarlar.token).catch(err => {
    console.error('Bot giriş yaparken hata oluştu:', err.message);
    console.log('made by kavun');
    console.log('ayarlar.js dosyasındaki tokeni kontrol edin!');
});
