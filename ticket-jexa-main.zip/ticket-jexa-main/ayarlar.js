const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'database.json');

function loadDB() {
    if (!fs.existsSync(dbPath)) return {};
    try {
        return JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    } catch {
        return {};
    }
}

function saveDB(data) {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

const db = loadDB();

module.exports = {
    token: "token",
    prefix: ".",
    
    get yetkiliRolID() {
        return db.yetkiliRolID || null;
    },
    
    set yetkiliRolID(val) {
        db.yetkiliRolID = val;
        saveDB(db);
    },
    
    get logKanalID() {
        return db.logKanalID || null;
    },
    
    set logKanalID(val) {
        db.logKanalID = val;
        saveDB(db);
    },
    
    get panelKanalID() {
        return db.panelKanalID || null;
    },
    
    set panelKanalID(val) {
        db.panelKanalID = val;
        saveDB(db);
    },
    
    get ticketKategoriID() {
        return db.ticketKategoriID || null;
    },
    
    set ticketKategoriID(val) {
        db.ticketKategoriID = val;
        saveDB(db);
    },
    
    get kategoriler() {
        return {
            genel: { 
                isim: "Genel Destek", 
                aciklama: "Genel sorular ve yardım",
                emoji: "<:info:1512228671929323681>",
                kategoriID: this.ticketKategoriID
            },
            teknik: { 
                isim: "Teknik Destek", 
                aciklama: "Teknik sorunlar ve hatalar",
                emoji: "<:ayarlar:1512403991072608390>",
                kategoriID: this.ticketKategoriID
            },
            satis: { 
                isim: "Satış & Paket", 
                aciklama: "Paket ve satın alma işlemleri",
                emoji: "<:buyutec:1512396876035653672>",
                kategoriID: this.ticketKategoriID
            },
            sikayet: { 
                isim: "Şikayet & Öneri", 
                aciklama: "Şikayetler ve öneriler",
                emoji: "<:ampul:1512404556737413311>",
                kategoriID: this.ticketKategoriID
            }
        };
    },
    
    mesajlar: {
        acilis: "Destek talebiniz oluşturuldu! Yetkili ekibimiz en kısa sürede size yardımcı olacaktır.",
        kapanis: "Destek talebi kapatıldı.",
        yetkiliUyari: "Lütfen yetkilileri gereksiz yere etiketlemeyiniz."
    },
    
    db: db,
    save: saveDB
};